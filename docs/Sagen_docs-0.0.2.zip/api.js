YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Android",
        "Browser",
        "Browser.Android",
        "Browser.Canvas",
        "Browser.Chrome",
        "Browser.Firefox",
        "Browser.IE",
        "Browser.Mobile",
        "Browser.Safari",
        "Browser.Touch",
        "Browser.iOS",
        "Device",
        "Sagen",
        "Viewport",
        "iOS"
    ],
    "modules": [
        "Sagen"
    ],
    "allModules": [
        {
            "displayName": "Sagen",
            "name": "Sagen"
        }
    ]
} };
});